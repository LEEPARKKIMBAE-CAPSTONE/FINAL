﻿# -*- coding: utf-8 -*-

from flask import Flask, render_template, request, send_file, url_for
from fund_db import signup_db, login_db
from flask.templating import render_template_string
import pandas as pd
import matplotlib.pyplot as plt
#from fbprophet import Prophet
from werkzeug.wrappers import Request, Response
import os

app = Flask(__name__)
app.secret_key = 'why would I tell you my secret key?'

# 회원가입
app.register_blueprint(signup_db.signup, url_prefix="/signup")
# 로그인
app.register_blueprint(login_db.login, url_prefix="/login")


@app.route("/", methods=['GET', 'POST'])
def index():
    return render_template('index.html')
'''
@app.route('/post', methods=['GET', 'POST'])
def post():
    if request.method == 'POST':
        value = request.form['num']
        value = int(value)

        df = pd.read_csv('./static/fund/fund_%d.csv' %value)
        df = df[['date', 'rate']].dropna()
        df['date'] = pd.to_datetime(df['date'])
        df = df.set_index('date')
        daily_df = df.resample('d').mean()
        d_df = daily_df.reset_index().dropna()

        d_df.columns = ['ds', 'y']
        fig = plt.figure(facecolor='w', figsize=(20, 6))

        m = Prophet()
        m.fit(d_df)
        future = m.make_future_dataframe(periods=500) # 미래 500일까지 더 예측
        forecast = m.predict(future)
        forecast[['ds', 'yhat', 'yhat_lower', 'yhat_upper']].tail()

        #미래 예측
        from datetime import datetime, timedelta
        fig1 = m.plot(forecast)
        datenow = datetime.now()
        #datenow = datetime(2021, 6, 10)
        dateend = datenow + timedelta(days=100)
        datestart = dateend - timedelta(days=450)

        plt.xlim([datestart, dateend])
        plt.title("%d fund recommend" %value, fontsize=20)
        plt.xlabel("Day", fontsize=20)
        plt.ylabel("price", fontsize=20)
        plt.axvline(datenow, color="k", linestyle=":")
        plt.rcParams["figure.figsize"] = (7,4)

        file = "./static/fund/fund.png"
        if os.path.isfile(file): #만약 이미 만들어진 fund.png있으면 삭제
            os.remove(file)
        plt.savefig('./static/fund/fund.png', bbox_inches = 'tight', pad_inches = 0) #무조건 plt.show이전에
    return render_template('predict.html')
'''
@app.route("/fundsearch.html", methods=['GET', 'POST'])
def fundSearch():
    return render_template('fundsearch.html')

@app.route("/predict.html", methods=['GET', 'POST'])
def fundTest():
    return render_template('predict.html')

@app.route("/analysis.html", methods=['GET', 'POST'])
def fundPredict():
    return render_template('analysis.html')

@app.route("/login.html", methods=['GET', 'POST'])
def fundLogin():
    return render_template('login.html')

@app.route("/signup.html", methods=['GET', 'POST'])
def fundSignUp():
    return render_template('signup.html')

@app.route("/ana_result.html", methods=['GET', 'POST'])
def fundResult():
    return render_template('ana_result.html')

if __name__ == '__main__':
    app.run( debug=True)
