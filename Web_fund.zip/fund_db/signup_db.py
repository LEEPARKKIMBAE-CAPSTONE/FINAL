from flask import Flask, Blueprint, render_template, request
import pymysql
from fund_db import mysql
#from fund_view import mysql

signup = Blueprint('signup', __name__)


@signup.route('/get_id', methods=['GET'])
def get_id():
    userid = request.args.get('userid')
    password = request.args.get('password')
    ck_password = request.args.get('ck_password')
    name = request.args.get('name')

    if not(userid and password and ck_password and name):
        return "입력되지 않은 정보가 있습니다."
    else:
        if password != ck_password:
            return "비밀번호가 일치하지 않습니다."

        else:
            conn = mysql.MYSQL_CONN
            cursor = conn.cursor()

            sql = "INSERT INTO user_info(id, password, name) VALUES ('%s', '%s', '%s')" % (
                str(userid), str(password), str(name))

            cursor.execute(sql)
            conn.commit()

        return "회원가입이 완료되었습니다!"
