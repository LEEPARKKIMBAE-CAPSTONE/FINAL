import pymysql

MYSQL_HOST = 'localhost'
MYSQL_CONN = pymysql.connect(
    host=MYSQL_HOST,
    port=3308,
    user='root',
    passwd='chaechae',
    db='user_info',
    charset='utf8'
)

'''
def conn_mysqldb():  # 재접속
    if not MYSQL_CONN.open:
        MYSQL_CONN.ping(reconnect=True)
    return MYSQL_CONN
'''
