from flask import session, Blueprint, render_template, request, redirect
from werkzeug.utils import redirect
from fund_db import mysql

login = Blueprint('login', __name__)

# login.secret_key = "lkjds#2-1j@dsp!ldaskfj"


@login.route('/home')
def home():
    if "userID" in session:  # 로그인 됐을 때
        return render_template("index.html", username=session.get("userID"), login_result=True)
    else:
        return render_template("index.html", login_result=False)


@login.route('/login_user', methods=['POST'])
def login_user():
    userid = request.form["userid"]
    userpw = request.form["password"]

    # connection DB
    conn = mysql.MYSQL_CONN
    cursor = conn.cursor()
    sql = "SELECT * FROM user_info where id = '%s' " % userid

    cursor.execute(sql)
    row = cursor.fetchone()

    conn.close()

    # row[0]: id, row[1]: password, row[2]:name
    if userid == row[0] and userpw == row[1]:
        session["userID"] = row[2]
        return redirect("/login/home")
    else:
        return redirect("/login/home")


@login.route("/logout")
def logout():
    session.pop("userID")
    return redirect("/login/home")
